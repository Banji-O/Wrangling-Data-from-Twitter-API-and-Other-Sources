#  Wrangling Data from Twitter API and Other Sources

#### by Banji R. Owabumoye
---

![twitter_stckabus.png](attachment:twitter_stckabus.png)

## Table of Contents

- [Introduction](#Introduction)
- [Data Gathering](#Data-Gathering)
    - [Manual download](#Manual-download)
    - [Programatic download](#Programmatic-download)
    - [Twitter API data](#Twitter-API-data)
- [Data Assessment](#Data-Assessment)
    - [Quality issues](#Quality-issues)
    - [Tidiness issues](#Tidiness-issues)
- [Data Cleaning](#Data-Cleaning)
    - [Storing data](#Storing-Data)
- [Analyzing and Visualizing Data](#Analyzing-and-Visualizing-Data)
    - [Visualizations](#Visualizations)
- [Resources](#Resources:)


## Introduction
<a id='## Introduction'></a>

---
Data wrangling is based on three major activities which are data gathering, data assessing, and data cleaning.
This project is based on wrangling dataset from tweet archive of Twitter user @dog_rates, also known as WeRateDogs. WeRateDogs is a Twitter account that rates people’s dogs with funny comment about the dog. This project adopted manual and programmatic methods to gather, assess and clean datasets.

Before I discuss how datasets used for this project were acquired, I will import all the packages and libraries needed for this project.

   **Importation of Packages**


```python
# importation of packages and libraries

import pandas as pd
import os
import requests
import time
import numpy as np
import tweepy
import calendar
import json
import seaborn as sns
import math
import matplotlib.pyplot as plt

%matplotlib inline
```

## Data Gathering
<a id='## Data-Gathering'></a>

---
Datasets were gathered manually and programmatically (using python programming language codes) from three different sources. A twitter-archive-enhanced dataset stored as comma separated value (csv) file was manually downloaded from Udacity platform. The second dataset gathered is a tab separated value (tsv) file, labelled ‘image_predictions.tsv’.  This dataset was programmatically downloaded from a Uniform Resource Locator (URL) through a library known as requests. The third dataset was gathered from Twitter API using Tweepy package to query the Javascript Object Notation (JSON) file labelled ‘tweet_json.txt’. To access this dataset, a developer account was requested for and granted by Twitter which made it possible to generate API Key, API Key Secret, Access Token, and Access Token Secret used as authenticator to access the data from archive. Twitter-archive-enhanced.csv, image_predictions.tsv, and tweet_json.txt datasets were loaded into Udacity workspace for assessment and cleaning.

#### Manual download 
<a id='#### Manual-download '></a>
A comma separated values (csv) was manually download from this [link.](https://d17h27t6h515a5.cloudfront.net/topher/2017/August/59a4e958_twitter-archive-enhanced/twitter-archive-enhanced.csv) Manual download is done when a link is clicked and the file downloaded directly.


```python
# loading of dataset downloaded manually.

tweeter_df = pd.read_csv('twitter-archive-enhanced.csv')
```

#### Programmatic download
<a id='#### Programmatic-download'></a>
This was achieved by using the Requests library to download the tab separated values (tsv) file that contains tweet image prediction.


```python
# creating new folder to save data downloaded from requests library
folder_name = 'banji'
if not os.path.exists(folder_name):
    os.makedirs(folder_name)
```


```python
# The website address to programmatically download data from
url = 'https://d17h27t6h515a5.cloudfront.net/topher/2017/August/599fd2ad_image-predictions/image-predictions.tsv'

# To download tsv file programmatically using request library
response = requests.get(url)

```


```python
# To access the content and write to file

with open(os.path.join(folder_name, url.split('/')[-1]), mode ='wb') as file:
    file.write(response.content)
```


```python
# To load downloaded tab separated value (tsv) file using pandas
image_df = pd.read_csv('image-predictions.tsv', sep='\t')
```

#### Twitter API data
<a id='#### Twitter-API-data'></a>
Data needed from twitter was ingested through twitter's Application Programming Interface (API) known as Tweepy. The ingested data is in JavaScript Object Notation (JSON) format. Accessing twitter API was possible after been admitted as Twitter developer.

After gathering all the dataset needed for this project, we will move to the second stage which is data assessment.


```python
# developer's confidential digital keys to access Twitter API through Tweepy
api_key = 'CONFIDENTIAL' # api_key should not be made public

api_key_secret = 'CONFIDENTIAL' # api_key_secret should not be made public

access_token = 'CONFIDENTIAL' # access_token should not be made public

access_token_secret = 'CONFIDENTIAL' # access_token_secret should not be made public
```


```python
# API accessbility authentication

auth = tweepy.OAuthHandler(api_key, api_key_secret)

auth.set_access_token(access_token, access_token_secret)

api = tweepy.API(auth, wait_on_rate_limit = True)
```


```python
# The unique tweet_id in tweeter_df dataframe
unique_twt_ids = [tweeter_df['tweet_id'].unique()]

#save the gathered data to a file
with open("tweet_json.txt", "w") as file:
    for tweet_id in unique_twt_ids:
        print(f"Gather id: {tweet_id}")
        try:
            #get all the twitter status - extended mode gives us additional data
            tweet = api.get_status(tweet_id, tweet_mode = "extended")
            #dump the json data to our file
            json.dump(tweet._json, file)
            #add a linebreak after each dump
            file.write('\n')
        except Exception as e:
            print(f"Error - id: {tweet_id}" + str(e))
```

    Gather id: [892420643555336193 892177421306343426 891815181378084864 ...
     666033412701032449 666029285002620928 666020888022790149]
    Error - id: [892420643555336193 892177421306343426 891815181378084864 ...
     666033412701032449 666029285002620928 666020888022790149]401 Unauthorized
    89 - Invalid or expired token.
    


```python
# saving gathered data to dataframe

tweeter_api_data = []

# To read the created file
with open('tweet_json.txt', 'r') as file:
    for data in file:
        try:
            tweet = json.loads(data)
            
            # append a dictionary to the created list
            tweeter_api_data.append({
                'tweet_id' : tweet['id'], 'retweet_count':tweet['retweet_count'],
                'favorite_count' : tweet['favorite_count']
            })
            
        except:
            print('error')
            
tweeter_api_df = pd.DataFrame(tweeter_api_data, columns = ['tweet_id', 'retweet_count', 'favorite_count'])
tweeter_api_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tweet_id</th>
      <th>retweet_count</th>
      <th>favorite_count</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
</div>




```python
tweeter_api_df = pd.read_csv('tweeter_api_df.csv')
```

## Data Assessment
<a id='## Data-Assessment'></a>

---
Just like data gathering, the three datasets were assessed visually or manually and assessed programmatically.  The datasets were visually assessed by looking at the dataframe of each dataset for quality and structural issues. Also, functions and methods were adopted to assess the datasets programmatically.  This assessment methods revealed quality and structural issues.

After the assessment, observed quality and structural issues were listed for cleaning.


```python
# to visualize the top rows of the dataframe
tweeter_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tweet_id</th>
      <th>in_reply_to_status_id</th>
      <th>in_reply_to_user_id</th>
      <th>timestamp</th>
      <th>source</th>
      <th>text</th>
      <th>retweeted_status_id</th>
      <th>retweeted_status_user_id</th>
      <th>retweeted_status_timestamp</th>
      <th>expanded_urls</th>
      <th>rating_numerator</th>
      <th>rating_denominator</th>
      <th>name</th>
      <th>doggo</th>
      <th>floofer</th>
      <th>pupper</th>
      <th>puppo</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>892420643555336193</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-08-01 16:23:56 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Phineas. He's a mystical boy. Only eve...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/892420643...</td>
      <td>13</td>
      <td>10</td>
      <td>Phineas</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1</th>
      <td>892177421306343426</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-08-01 00:17:27 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Tilly. She's just checking pup on you....</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/892177421...</td>
      <td>13</td>
      <td>10</td>
      <td>Tilly</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2</th>
      <td>891815181378084864</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-31 00:18:03 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Archie. He is a rare Norwegian Pouncin...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/891815181...</td>
      <td>12</td>
      <td>10</td>
      <td>Archie</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>3</th>
      <td>891689557279858688</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-30 15:58:51 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Darla. She commenced a snooze mid meal...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/891689557...</td>
      <td>13</td>
      <td>10</td>
      <td>Darla</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>4</th>
      <td>891327558926688256</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-29 16:00:24 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Franklin. He would like you to stop ca...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/891327558...</td>
      <td>12</td>
      <td>10</td>
      <td>Franklin</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
  </tbody>
</table>
</div>




```python
# to visualize the last few rows of the dataframe
tweeter_df.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tweet_id</th>
      <th>in_reply_to_status_id</th>
      <th>in_reply_to_user_id</th>
      <th>timestamp</th>
      <th>source</th>
      <th>text</th>
      <th>retweeted_status_id</th>
      <th>retweeted_status_user_id</th>
      <th>retweeted_status_timestamp</th>
      <th>expanded_urls</th>
      <th>rating_numerator</th>
      <th>rating_denominator</th>
      <th>name</th>
      <th>doggo</th>
      <th>floofer</th>
      <th>pupper</th>
      <th>puppo</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2351</th>
      <td>666049248165822465</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-16 00:24:50 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>Here we have a 1949 1st generation vulpix. Enj...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666049248...</td>
      <td>5</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2352</th>
      <td>666044226329800704</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-16 00:04:52 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is a purebred Piers Morgan. Loves to Netf...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666044226...</td>
      <td>6</td>
      <td>10</td>
      <td>a</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2353</th>
      <td>666033412701032449</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-15 23:21:54 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>Here is a very happy pup. Big fan of well-main...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666033412...</td>
      <td>9</td>
      <td>10</td>
      <td>a</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2354</th>
      <td>666029285002620928</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-15 23:05:30 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is a western brown Mitsubishi terrier. Up...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666029285...</td>
      <td>7</td>
      <td>10</td>
      <td>a</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2355</th>
      <td>666020888022790149</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-15 22:32:08 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>Here we have a Japanese Irish Setter. Lost eye...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666020888...</td>
      <td>8</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
  </tbody>
</table>
</div>




```python
# getting more details of the dataframe programmatically
tweeter_df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 2356 entries, 0 to 2355
    Data columns (total 17 columns):
     #   Column                      Non-Null Count  Dtype  
    ---  ------                      --------------  -----  
     0   tweet_id                    2356 non-null   int64  
     1   in_reply_to_status_id       78 non-null     float64
     2   in_reply_to_user_id         78 non-null     float64
     3   timestamp                   2356 non-null   object 
     4   source                      2356 non-null   object 
     5   text                        2356 non-null   object 
     6   retweeted_status_id         181 non-null    float64
     7   retweeted_status_user_id    181 non-null    float64
     8   retweeted_status_timestamp  181 non-null    object 
     9   expanded_urls               2297 non-null   object 
     10  rating_numerator            2356 non-null   int64  
     11  rating_denominator          2356 non-null   int64  
     12  name                        2356 non-null   object 
     13  doggo                       2356 non-null   object 
     14  floofer                     2356 non-null   object 
     15  pupper                      2356 non-null   object 
     16  puppo                       2356 non-null   object 
    dtypes: float64(4), int64(3), object(10)
    memory usage: 313.0+ KB
    


```python
# having descriptive view of the dataframe
tweeter_df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tweet_id</th>
      <th>in_reply_to_status_id</th>
      <th>in_reply_to_user_id</th>
      <th>retweeted_status_id</th>
      <th>retweeted_status_user_id</th>
      <th>rating_numerator</th>
      <th>rating_denominator</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>2.356000e+03</td>
      <td>7.800000e+01</td>
      <td>7.800000e+01</td>
      <td>1.810000e+02</td>
      <td>1.810000e+02</td>
      <td>2356.000000</td>
      <td>2356.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>7.427716e+17</td>
      <td>7.455079e+17</td>
      <td>2.014171e+16</td>
      <td>7.720400e+17</td>
      <td>1.241698e+16</td>
      <td>13.126486</td>
      <td>10.455433</td>
    </tr>
    <tr>
      <th>std</th>
      <td>6.856705e+16</td>
      <td>7.582492e+16</td>
      <td>1.252797e+17</td>
      <td>6.236928e+16</td>
      <td>9.599254e+16</td>
      <td>45.876648</td>
      <td>6.745237</td>
    </tr>
    <tr>
      <th>min</th>
      <td>6.660209e+17</td>
      <td>6.658147e+17</td>
      <td>1.185634e+07</td>
      <td>6.661041e+17</td>
      <td>7.832140e+05</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>6.783989e+17</td>
      <td>6.757419e+17</td>
      <td>3.086374e+08</td>
      <td>7.186315e+17</td>
      <td>4.196984e+09</td>
      <td>10.000000</td>
      <td>10.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>7.196279e+17</td>
      <td>7.038708e+17</td>
      <td>4.196984e+09</td>
      <td>7.804657e+17</td>
      <td>4.196984e+09</td>
      <td>11.000000</td>
      <td>10.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>7.993373e+17</td>
      <td>8.257804e+17</td>
      <td>4.196984e+09</td>
      <td>8.203146e+17</td>
      <td>4.196984e+09</td>
      <td>12.000000</td>
      <td>10.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>8.924206e+17</td>
      <td>8.862664e+17</td>
      <td>8.405479e+17</td>
      <td>8.874740e+17</td>
      <td>7.874618e+17</td>
      <td>1776.000000</td>
      <td>170.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
# to visualize the top rows of the dataframe
image_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tweet_id</th>
      <th>jpg_url</th>
      <th>img_num</th>
      <th>p1</th>
      <th>p1_conf</th>
      <th>p1_dog</th>
      <th>p2</th>
      <th>p2_conf</th>
      <th>p2_dog</th>
      <th>p3</th>
      <th>p3_conf</th>
      <th>p3_dog</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>666020888022790149</td>
      <td>https://pbs.twimg.com/media/CT4udn0WwAA0aMy.jpg</td>
      <td>1</td>
      <td>Welsh_springer_spaniel</td>
      <td>0.465074</td>
      <td>True</td>
      <td>collie</td>
      <td>0.156665</td>
      <td>True</td>
      <td>Shetland_sheepdog</td>
      <td>0.061428</td>
      <td>True</td>
    </tr>
    <tr>
      <th>1</th>
      <td>666029285002620928</td>
      <td>https://pbs.twimg.com/media/CT42GRgUYAA5iDo.jpg</td>
      <td>1</td>
      <td>redbone</td>
      <td>0.506826</td>
      <td>True</td>
      <td>miniature_pinscher</td>
      <td>0.074192</td>
      <td>True</td>
      <td>Rhodesian_ridgeback</td>
      <td>0.072010</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2</th>
      <td>666033412701032449</td>
      <td>https://pbs.twimg.com/media/CT4521TWwAEvMyu.jpg</td>
      <td>1</td>
      <td>German_shepherd</td>
      <td>0.596461</td>
      <td>True</td>
      <td>malinois</td>
      <td>0.138584</td>
      <td>True</td>
      <td>bloodhound</td>
      <td>0.116197</td>
      <td>True</td>
    </tr>
    <tr>
      <th>3</th>
      <td>666044226329800704</td>
      <td>https://pbs.twimg.com/media/CT5Dr8HUEAA-lEu.jpg</td>
      <td>1</td>
      <td>Rhodesian_ridgeback</td>
      <td>0.408143</td>
      <td>True</td>
      <td>redbone</td>
      <td>0.360687</td>
      <td>True</td>
      <td>miniature_pinscher</td>
      <td>0.222752</td>
      <td>True</td>
    </tr>
    <tr>
      <th>4</th>
      <td>666049248165822465</td>
      <td>https://pbs.twimg.com/media/CT5IQmsXIAAKY4A.jpg</td>
      <td>1</td>
      <td>miniature_pinscher</td>
      <td>0.560311</td>
      <td>True</td>
      <td>Rottweiler</td>
      <td>0.243682</td>
      <td>True</td>
      <td>Doberman</td>
      <td>0.154629</td>
      <td>True</td>
    </tr>
  </tbody>
</table>
</div>




```python
# to visualize the last few rows of the dataframe
image_df.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tweet_id</th>
      <th>jpg_url</th>
      <th>img_num</th>
      <th>p1</th>
      <th>p1_conf</th>
      <th>p1_dog</th>
      <th>p2</th>
      <th>p2_conf</th>
      <th>p2_dog</th>
      <th>p3</th>
      <th>p3_conf</th>
      <th>p3_dog</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2070</th>
      <td>891327558926688256</td>
      <td>https://pbs.twimg.com/media/DF6hr6BUMAAzZgT.jpg</td>
      <td>2</td>
      <td>basset</td>
      <td>0.555712</td>
      <td>True</td>
      <td>English_springer</td>
      <td>0.225770</td>
      <td>True</td>
      <td>German_short-haired_pointer</td>
      <td>0.175219</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2071</th>
      <td>891689557279858688</td>
      <td>https://pbs.twimg.com/media/DF_q7IAWsAEuuN8.jpg</td>
      <td>1</td>
      <td>paper_towel</td>
      <td>0.170278</td>
      <td>False</td>
      <td>Labrador_retriever</td>
      <td>0.168086</td>
      <td>True</td>
      <td>spatula</td>
      <td>0.040836</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2072</th>
      <td>891815181378084864</td>
      <td>https://pbs.twimg.com/media/DGBdLU1WsAANxJ9.jpg</td>
      <td>1</td>
      <td>Chihuahua</td>
      <td>0.716012</td>
      <td>True</td>
      <td>malamute</td>
      <td>0.078253</td>
      <td>True</td>
      <td>kelpie</td>
      <td>0.031379</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2073</th>
      <td>892177421306343426</td>
      <td>https://pbs.twimg.com/media/DGGmoV4XsAAUL6n.jpg</td>
      <td>1</td>
      <td>Chihuahua</td>
      <td>0.323581</td>
      <td>True</td>
      <td>Pekinese</td>
      <td>0.090647</td>
      <td>True</td>
      <td>papillon</td>
      <td>0.068957</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2074</th>
      <td>892420643555336193</td>
      <td>https://pbs.twimg.com/media/DGKD1-bXoAAIAUK.jpg</td>
      <td>1</td>
      <td>orange</td>
      <td>0.097049</td>
      <td>False</td>
      <td>bagel</td>
      <td>0.085851</td>
      <td>False</td>
      <td>banana</td>
      <td>0.076110</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
</div>




```python
# getting more details of the dataframe programmatically
image_df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 2075 entries, 0 to 2074
    Data columns (total 12 columns):
     #   Column    Non-Null Count  Dtype  
    ---  ------    --------------  -----  
     0   tweet_id  2075 non-null   int64  
     1   jpg_url   2075 non-null   object 
     2   img_num   2075 non-null   int64  
     3   p1        2075 non-null   object 
     4   p1_conf   2075 non-null   float64
     5   p1_dog    2075 non-null   bool   
     6   p2        2075 non-null   object 
     7   p2_conf   2075 non-null   float64
     8   p2_dog    2075 non-null   bool   
     9   p3        2075 non-null   object 
     10  p3_conf   2075 non-null   float64
     11  p3_dog    2075 non-null   bool   
    dtypes: bool(3), float64(3), int64(2), object(4)
    memory usage: 152.1+ KB
    


```python
# having descriptive view of the dataframe
image_df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tweet_id</th>
      <th>img_num</th>
      <th>p1_conf</th>
      <th>p2_conf</th>
      <th>p3_conf</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>2.075000e+03</td>
      <td>2075.000000</td>
      <td>2075.000000</td>
      <td>2.075000e+03</td>
      <td>2.075000e+03</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>7.384514e+17</td>
      <td>1.203855</td>
      <td>0.594548</td>
      <td>1.345886e-01</td>
      <td>6.032417e-02</td>
    </tr>
    <tr>
      <th>std</th>
      <td>6.785203e+16</td>
      <td>0.561875</td>
      <td>0.271174</td>
      <td>1.006657e-01</td>
      <td>5.090593e-02</td>
    </tr>
    <tr>
      <th>min</th>
      <td>6.660209e+17</td>
      <td>1.000000</td>
      <td>0.044333</td>
      <td>1.011300e-08</td>
      <td>1.740170e-10</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>6.764835e+17</td>
      <td>1.000000</td>
      <td>0.364412</td>
      <td>5.388625e-02</td>
      <td>1.622240e-02</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>7.119988e+17</td>
      <td>1.000000</td>
      <td>0.588230</td>
      <td>1.181810e-01</td>
      <td>4.944380e-02</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>7.932034e+17</td>
      <td>1.000000</td>
      <td>0.843855</td>
      <td>1.955655e-01</td>
      <td>9.180755e-02</td>
    </tr>
    <tr>
      <th>max</th>
      <td>8.924206e+17</td>
      <td>4.000000</td>
      <td>1.000000</td>
      <td>4.880140e-01</td>
      <td>2.734190e-01</td>
    </tr>
  </tbody>
</table>
</div>




```python
# to visualize the top rows of the dataframe
tweeter_api_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tweet_id</th>
      <th>retweet_count</th>
      <th>favorite_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>892420643555336193</td>
      <td>8853</td>
      <td>39467</td>
    </tr>
    <tr>
      <th>1</th>
      <td>892177421306343426</td>
      <td>6514</td>
      <td>33819</td>
    </tr>
    <tr>
      <th>2</th>
      <td>891815181378084864</td>
      <td>4328</td>
      <td>25461</td>
    </tr>
    <tr>
      <th>3</th>
      <td>891689557279858688</td>
      <td>8964</td>
      <td>42908</td>
    </tr>
    <tr>
      <th>4</th>
      <td>891327558926688256</td>
      <td>9774</td>
      <td>41048</td>
    </tr>
  </tbody>
</table>
</div>




```python
# to visualize the last few rows of the dataframe
tweeter_api_df.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tweet_id</th>
      <th>retweet_count</th>
      <th>favorite_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2349</th>
      <td>666049248165822465</td>
      <td>41</td>
      <td>111</td>
    </tr>
    <tr>
      <th>2350</th>
      <td>666044226329800704</td>
      <td>147</td>
      <td>311</td>
    </tr>
    <tr>
      <th>2351</th>
      <td>666033412701032449</td>
      <td>47</td>
      <td>128</td>
    </tr>
    <tr>
      <th>2352</th>
      <td>666029285002620928</td>
      <td>48</td>
      <td>132</td>
    </tr>
    <tr>
      <th>2353</th>
      <td>666020888022790149</td>
      <td>532</td>
      <td>2535</td>
    </tr>
  </tbody>
</table>
</div>




```python
# getting more details of the dataframe programmatically
tweeter_api_df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 2354 entries, 0 to 2353
    Data columns (total 3 columns):
     #   Column          Non-Null Count  Dtype
    ---  ------          --------------  -----
     0   tweet_id        2354 non-null   int64
     1   retweet_count   2354 non-null   int64
     2   favorite_count  2354 non-null   int64
    dtypes: int64(3)
    memory usage: 55.3 KB
    


```python
# having descriptive view of the dataframe
tweeter_api_df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tweet_id</th>
      <th>retweet_count</th>
      <th>favorite_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>2.354000e+03</td>
      <td>2354.000000</td>
      <td>2354.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>7.426978e+17</td>
      <td>3164.797366</td>
      <td>8080.968564</td>
    </tr>
    <tr>
      <th>std</th>
      <td>6.852812e+16</td>
      <td>5284.770364</td>
      <td>11814.771334</td>
    </tr>
    <tr>
      <th>min</th>
      <td>6.660209e+17</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>6.783975e+17</td>
      <td>624.500000</td>
      <td>1415.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>7.194596e+17</td>
      <td>1473.500000</td>
      <td>3603.500000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>7.993058e+17</td>
      <td>3652.000000</td>
      <td>10122.250000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>8.924206e+17</td>
      <td>79515.000000</td>
      <td>132810.000000</td>
    </tr>
  </tbody>
</table>
</div>



#### Quality issues

<a id='#### Quality-issues'></a>
1. Doggo, floofer, pupper, and puppo columns have values as      'None'

2. Platform sources embedded in html code in source column 

3. Timestamp datatype is object instead of datetime

4. Over 2000 null values in eachcolumn(in_reply_to_status_id,    in_reply_to_user_id, retweeted_status_id,                    retweeted_status_user_id, retweeted_status_timestamp)

5. Tweet_id datatype is int64 instead of object

6. Inconsistency in p1 column case, some are upper while some    are lower and underscore in between words

7. Incosistency in p2 column case, some are uppr while some      are lower and underscore in between words

8. Incosistency in p3 column case, some are uppr while some      are lower and underscore in between words

9. Tweet_id datatype is int64 rather than object

10. Column names except tweet_id are not descriptive

#### Tidiness issues
<a id ='#### Tidiness-issues'></a>

1. Doggo, floofer, pupper, and puppo should not have separate    columns

2. Day_name, month, and year_month columns from timestamp        column

3. Tweeter_df, image_df, and tweeter_api_df dataframes should    merged together since they all have tweet_id column

4. doggo, pupper, floofer, and puppo columns are no more        needed

## Data Cleaning
<a id = '## Data-Cleaning'></a>

---
As expected, copies of dataframes to be cleaned were created. Quality issues and structural issues were cleaned programmatically by defining issues, writing code to clean the issues, and testing the outcome to ascertain the cleanness. Quality and structural changes made are:

-	none values in doggo, floofer, pupper, and puppo columns were changed to Nan
-	platforms used for tweeting were extracted from html code
-	timestamp column made datetime datatype
-	in_reply_to_status_id, in_reply_to_user_id, retweeted_status_id, retweeted_status_user_id,, and  retweeted_status_timestamp columns were dropped
-	tweet_id columns in all the dataframes changed to object datatype
-	p1, p2, and p3 columns’ values were changed to lowercase and underscore replaced with space
-	column labels were made descriptive
-	doggo, pupper, floofer, and puppo values merged into newly created dog stage column
-	day_name, month, and year_month columns were added
-	tweeter_df, image_df, and tweeter_api_df dataframes were merged into one dataframe and named twitter_archive_master
-	doggo, pupper, floofer, and puppo columns were dropped.

Once the datasets are clean, the next task will be to store them as a single csv or flat file.


```python
# Make copies of original pieces of data

twt_clean_df = tweeter_df.copy()
image_clean_df = image_df.copy()
api_clean_df = tweeter_api_df.copy()
```

#### Quality Issues

>#### Issue #1: doggo, floofer, pupper, and puppo columns have values as 'None'

>#### Define: doggo, floofer, pupper, and puppo columns nan values represented as 'None' will be changed to nan with replace function.

#### Code


```python
# to replace 'None' to nan in doggo column
twt_clean_df.doggo.replace('None', np.nan, inplace=True)
```


```python
# to replace 'None' to nan in floofer column
twt_clean_df.floofer.replace('None', np.nan, inplace=True)
```


```python
# to replace 'None' to nan in pupper column
twt_clean_df.pupper.replace('None', np.nan, inplace=True)
```


```python
# to replace 'None' to nan in puppo column
twt_clean_df.puppo.replace('None', np.nan, inplace=True)
```

#### Test


```python
# to view the first rows of the dataframe to consider the changes
twt_clean_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tweet_id</th>
      <th>in_reply_to_status_id</th>
      <th>in_reply_to_user_id</th>
      <th>timestamp</th>
      <th>source</th>
      <th>text</th>
      <th>retweeted_status_id</th>
      <th>retweeted_status_user_id</th>
      <th>retweeted_status_timestamp</th>
      <th>expanded_urls</th>
      <th>rating_numerator</th>
      <th>rating_denominator</th>
      <th>name</th>
      <th>doggo</th>
      <th>floofer</th>
      <th>pupper</th>
      <th>puppo</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>892420643555336193</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-08-01 16:23:56 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Phineas. He's a mystical boy. Only eve...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/892420643...</td>
      <td>13</td>
      <td>10</td>
      <td>Phineas</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>892177421306343426</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-08-01 00:17:27 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Tilly. She's just checking pup on you....</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/892177421...</td>
      <td>13</td>
      <td>10</td>
      <td>Tilly</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>891815181378084864</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-31 00:18:03 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Archie. He is a rare Norwegian Pouncin...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/891815181...</td>
      <td>12</td>
      <td>10</td>
      <td>Archie</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>891689557279858688</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-30 15:58:51 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Darla. She commenced a snooze mid meal...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/891689557...</td>
      <td>13</td>
      <td>10</td>
      <td>Darla</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>891327558926688256</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-29 16:00:24 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Franklin. He would like you to stop ca...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/891327558...</td>
      <td>12</td>
      <td>10</td>
      <td>Franklin</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>



>#### Issue #2: platform sources embedded in html code in source column

>#### Define: iphone, twitter, vine, and tweet deck are sources of tweet embedded in url and html code. These sources will be extracted with replace function

#### Code


```python
# To know the distinct values of source column
twt_clean_df.source.value_counts()
```




    <a href="http://twitter.com/download/iphone" rel="nofollow">Twitter for iPhone</a>     2221
    <a href="http://vine.co" rel="nofollow">Vine - Make a Scene</a>                          91
    <a href="http://twitter.com" rel="nofollow">Twitter Web Client</a>                       33
    <a href="https://about.twitter.com/products/tweetdeck" rel="nofollow">TweetDeck</a>      11
    Name: source, dtype: int64




```python
# To extract iphone platform from source column
twt_clean_df.source.replace('<a href="http://twitter.com/download/iphone" rel="nofollow">Twitter for iPhone</a>','iphone', inplace = True)
```


```python
# To extract vine platform from source column
twt_clean_df.source.replace('<a href="http://vine.co" rel="nofollow">Vine - Make a Scene</a>','vine', inplace = True)
```


```python
# To extract twitter from source column
twt_clean_df.source.replace('<a href="http://twitter.com" rel="nofollow">Twitter Web Client</a>', 'twitter', inplace = True)
```


```python
# To extract tweetdeck from source column
twt_clean_df.source.replace('<a href="https://about.twitter.com/products/tweetdeck" rel="nofollow">TweetDeck</a>', 'tweetdeck', inplace = True)
```

#### Test


```python
twt_clean_df.source.value_counts()
```




    iphone       2221
    vine           91
    twitter        33
    tweetdeck      11
    Name: source, dtype: int64



>#### Issue #3: timestamp datatype is object instead of datetime

>#### Define: timestamp datatype will be converted to datetime datatype in order to perform analysis with it

#### Code


```python
# Removing new lines from  timestamp column
twt_clean_df.timestamp = pd.to_datetime(twt_clean_df.timestamp)
```

#### Test


```python
# checking the datatype of timestamp
twt_clean_df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 2356 entries, 0 to 2355
    Data columns (total 16 columns):
     #   Column              Non-Null Count  Dtype              
    ---  ------              --------------  -----              
     0   tweet_id            2356 non-null   object             
     1   timestamp           2356 non-null   datetime64[ns, UTC]
     2   source              2356 non-null   object             
     3   text                2356 non-null   object             
     4   expanded_urls       2297 non-null   object             
     5   rating_numerator    2356 non-null   int64              
     6   rating_denominator  2356 non-null   int64              
     7   name                2356 non-null   object             
     8   doggo               97 non-null     object             
     9   floofer             10 non-null     object             
     10  pupper              257 non-null    object             
     11  puppo               30 non-null     object             
     12  dog_stage           380 non-null    object             
     13  day_name            2356 non-null   object             
     14  month               2356 non-null   object             
     15  year_month          2356 non-null   period[M]          
    dtypes: datetime64[ns, UTC](1), int64(2), object(12), period[M](1)
    memory usage: 294.6+ KB
    

>#### Issue #4: over 2000 null values in each column(in_reply_to_status_id, in_reply_to_user_id, retweeted_status_id, retweeted_status_user_id, retweeted_status_timestamp)

>#### Define : Columns such as in_reply_to_status_id, in_reply_to_user_id, retweeted_status_id, retweeted_status_user_id, and retweeted_status_timestamp with very few values will be droped from the dataframe

#### Code


```python
# Removing columns that are not needed
twt_clean_df.drop(['in_reply_to_status_id','in_reply_to_user_id','retweeted_status_id','retweeted_status_user_id','retweeted_status_timestamp'], axis = 1, inplace = True)
```

#### Test


```python
# checking the columns of the dataframe
twt_clean_df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 2356 entries, 0 to 2355
    Data columns (total 12 columns):
     #   Column              Non-Null Count  Dtype              
    ---  ------              --------------  -----              
     0   tweet_id            2356 non-null   int64              
     1   timestamp           2356 non-null   datetime64[ns, UTC]
     2   source              2356 non-null   object             
     3   text                2356 non-null   object             
     4   expanded_urls       2297 non-null   object             
     5   rating_numerator    2356 non-null   int64              
     6   rating_denominator  2356 non-null   int64              
     7   name                2356 non-null   object             
     8   doggo               97 non-null     object             
     9   floofer             10 non-null     object             
     10  pupper              257 non-null    object             
     11  puppo               30 non-null     object             
    dtypes: datetime64[ns, UTC](1), int64(3), object(8)
    memory usage: 221.0+ KB
    

>#### Issue #5: tweet_id datatype is int64 instead of object

>#### Define: tweet_id datatype will be changed from int64 to object

#### Code


```python
# changing tweet_id datatype from int64 to object
twt_clean_df['tweet_id']= twt_clean_df['tweet_id'].astype(str)
```

#### Test


```python
# to confirm datatype change
twt_clean_df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 2356 entries, 0 to 2355
    Data columns (total 12 columns):
     #   Column              Non-Null Count  Dtype              
    ---  ------              --------------  -----              
     0   tweet_id            2356 non-null   object             
     1   timestamp           2356 non-null   datetime64[ns, UTC]
     2   source              2356 non-null   object             
     3   text                2356 non-null   object             
     4   expanded_urls       2297 non-null   object             
     5   rating_numerator    2356 non-null   int64              
     6   rating_denominator  2356 non-null   int64              
     7   name                2356 non-null   object             
     8   doggo               97 non-null     object             
     9   floofer             10 non-null     object             
     10  pupper              257 non-null    object             
     11  puppo               30 non-null     object             
    dtypes: datetime64[ns, UTC](1), int64(2), object(9)
    memory usage: 221.0+ KB
    

>#### Issue #6: inconsistency in p1 column case, some are upper while some are lower and underscore in between words

>#### Define: Words in p1 column will be changed to lower case and hyphen between words will be replaced with space in order to maintain consistency

#### Code


```python
# changing values in p1 column to lower case and replacing '-' with ''
image_clean_df['p1'] = image_clean_df.p1.str.replace('_',' ').str.lower()
```

#### Test


```python
# confirming the changes
image_clean_df.p1.sample(3)
```




    281            goose
    1781    hippopotamus
    1237     boston bull
    Name: p1, dtype: object



>#### Issue #7: incosistency in p2 column case, some are uppr while some are lower and underscore in between words

>#### Define: Words in p2 column will be changed to lower case and hyphen between words will be replaced with space in order to maintain consistency

#### Code


```python
# changing values in p1 column to lower case and replacing '-' with ''
image_clean_df['p2'] = image_clean_df.p2.str.replace('_',' ').str.lower()
```

#### Test


```python
# confirming the changes
image_clean_df.p2.sample(3)
```




    166         coral reef
    1472    cocker spaniel
    1718        toy poodle
    Name: p2, dtype: object



>#### Issue #8: incosistency in p3 column case, some are uppr while some are lower and underscore in between words

>#### Define:  Words in p3 column will be changed to lower case and hyphen between words will be replaced with space in order to maintain consistency

#### Code


```python
# changing values in p1 column to lower case and replacing '-' with ''
image_clean_df['p3'] = image_clean_df.p3.str.replace('_',' ').str.lower()
```

#### Test


```python
# confirming the changes
image_clean_df.p3.sample(3)
```




    787           ice bear
    1618    cocker spaniel
    1336       siamese cat
    Name: p3, dtype: object



>#### Issue #9: tweet_id datatype is int64 rather than object

>#### Define: tweet_id datatype will be changed int64 to object

#### Code


```python
# changing tweet_id datatype from int64 to object
image_clean_df['tweet_id'] = image_clean_df['tweet_id'].astype(str)
```

#### Test


```python
# to confirm datatype change
image_clean_df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 2075 entries, 0 to 2074
    Data columns (total 12 columns):
     #   Column    Non-Null Count  Dtype  
    ---  ------    --------------  -----  
     0   tweet_id  2075 non-null   object 
     1   jpg_url   2075 non-null   object 
     2   img_num   2075 non-null   int64  
     3   p1        2075 non-null   object 
     4   p1_conf   2075 non-null   float64
     5   p1_dog    2075 non-null   bool   
     6   p2        2075 non-null   object 
     7   p2_conf   2075 non-null   float64
     8   p2_dog    2075 non-null   bool   
     9   p3        2075 non-null   object 
     10  p3_conf   2075 non-null   float64
     11  p3_dog    2075 non-null   bool   
    dtypes: bool(3), float64(3), int64(1), object(5)
    memory usage: 152.1+ KB
    

>#### Issue #10: column names except tweet_id are not descriptive

>#### Deine: all the column names of image_df dataframe will be descriptively renamed except tweet_id

#### Code


```python
# renaming of image_df columns
image_clean_df.rename(columns={'jpg_url':'image_url', 'img_num':'image_number', 'img_num':'image_number', 'p1':'first_prediction', 'p1_conf': 'first_confidence', 'p1_dog': 'first_dog',
                                  'p2': 'second_prediction', 'p2_conf': 'second_confidence', 'p2_dog': 'second_dog',
                                  'p3': 'third_prediction', 'p3_conf': 'third_confidence', 'p3_dog': 'third_dog'}, inplace = True)

```

#### Test


```python
# to confirm the columns rename
image_clean_df.columns
```




    Index(['tweet_id', 'image_url', 'image_number', 'first_prediction',
           'first_confidence', 'first_dog', 'second_prediction',
           'second_confidence', 'second_dog', 'third_prediction',
           'third_confidence', 'third_dog'],
          dtype='object')



>#### Structural Issues

>#### Issue 1: doggo, floofer, pupper, and puppo should not have separate columns

>#### Define: columns such as doggo, floofer, pupper, and puppo in twt_clean_df will be combined into one column named dog_stage

#### Code


```python
# combining doggo, floofer, pupper, and puppo into dog_stage column
twt_clean_df['dog_stage'] = twt_clean_df['doggo'
                                        ].map(str) + twt_clean_df['floofer'
                                                                 ].map(str) + twt_clean_df['pupper'
                                                                                          ].map(str) + twt_clean_df['puppo'].map(str)

```


```python
# To know distinct values in dog_stage column 
twt_clean_df.dog_stage.value_counts()
```




    nannannannan          1976
    nannanpuppernan        245
    doggonannannan          83
    nannannanpuppo          29
    doggonanpuppernan       12
    nanfloofernannan         9
    doggonannanpuppo         1
    doggofloofernannan       1
    Name: dog_stage, dtype: int64




```python
# function to separate combined values of pupper, doggo, floofer, and puppo columns in dog_stage column
def dog_stage(old_value, new_value):
    """ Combined values of pupper, doggo, floofer, and puppo columns in 
    dog_stage column were distinctly separated    
    """
    twt_clean_df.dog_stage.replace(old_value, new_value, inplace = True)
```


```python
# replacing dog stage column value
dog_stage('nannannannan', np.nan)
```


```python
# replacing dog stage column value
dog_stage('nannanpuppernan', 'pupper')
```


```python
# replacing dog stage column value
dog_stage('doggonannannan', 'doggo')
```


```python
# replacing dog stage column value
dog_stage('nannannanpuppo', 'puppo')
```


```python
# replacing dog stage column value
dog_stage('doggonanpuppernan', 'doggo')
```


```python
# replacing dog stage column value
dog_stage('nanfloofernannan', 'floofer')
```


```python
# replacing dog stage column value
dog_stage('doggonannanpuppo', 'doggo')
```


```python
# replacing dog stage column value
dog_stage('doggofloofernannan', 'doggo')
```

#### Test


```python
# confirming the distinct values of dog_stage column
twt_clean_df.dog_stage.value_counts()
```




    pupper     245
    doggo       97
    puppo       29
    floofer      9
    Name: dog_stage, dtype: int64



>#### Issue #2: day_name, month, and year columns from timestamp column

>#### Define: Three columns (day_name, month, and year_month) will be extracted from timestamp column

#### Code


```python
# extracting names of the week from timestamp
twt_clean_df['day_name'] = twt_clean_df['timestamp'].dt.day_name()
```


```python
# extracting names of month in calendar year from timestamp
twt_clean_df['month'] = pd.to_datetime(twt_clean_df['timestamp']).dt.strftime('%B')
```


```python
# extracting year_month from timestamp
twt_clean_df['year_month'] = pd.to_datetime(twt_clean_df["timestamp"]).dt.to_period('M')
```

    C:\ProgramData\Anaconda3\lib\site-packages\pandas\core\arrays\datetimes.py:1162: UserWarning: Converting to PeriodArray/Index representation will drop timezone information.
      warnings.warn(
    

#### Test


```python
twt_clean_df.sample(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tweet_id</th>
      <th>timestamp</th>
      <th>source</th>
      <th>text</th>
      <th>expanded_urls</th>
      <th>rating_numerator</th>
      <th>rating_denominator</th>
      <th>name</th>
      <th>doggo</th>
      <th>floofer</th>
      <th>pupper</th>
      <th>puppo</th>
      <th>dog_stage</th>
      <th>day_name</th>
      <th>month</th>
      <th>year_month</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1287</th>
      <td>708356463048204288</td>
      <td>2016-03-11 18:18:36+00:00</td>
      <td>iphone</td>
      <td>This is Oliver. That is his castle. He protect...</td>
      <td>https://twitter.com/dog_rates/status/708356463...</td>
      <td>10</td>
      <td>10</td>
      <td>Oliver</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Friday</td>
      <td>March</td>
      <td>2016-03</td>
    </tr>
    <tr>
      <th>389</th>
      <td>826476773533745153</td>
      <td>2017-01-31 17:06:32+00:00</td>
      <td>iphone</td>
      <td>This is Pilot. He has mastered the synchronize...</td>
      <td>https://twitter.com/dog_rates/status/826476773...</td>
      <td>12</td>
      <td>10</td>
      <td>Pilot</td>
      <td>doggo</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>doggo</td>
      <td>Tuesday</td>
      <td>January</td>
      <td>2017-01</td>
    </tr>
  </tbody>
</table>
</div>



>#### Issue #3: twt_clean_df, image_clean_df, and api_clean_df dataframes should merged together since they all have tweet_id column

>#### Define: twt_clean_df, image_clean_df, and api_clean_df will be merged and be named as twitter_archive_master

#### Code


```python
# changing tweet_id datatype from int64 to object
api_clean_df['tweet_id']= api_clean_df['tweet_id'].astype(str)
```


```python
# merging of dataframes
twitter_archive_master = pd.merge(pd.merge(twt_clean_df, image_clean_df, on ='tweet_id', how='left'), api_clean_df, on='tweet_id', how='left')

twitter_archive_master = pd.read_csv('twitter_archive_master.csv')
```

#### Test


```python
# To see the new dataframe (twitter_archive_master)
twitter_archive_master.sample(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tweet_id</th>
      <th>timestamp</th>
      <th>source</th>
      <th>text</th>
      <th>expanded_urls</th>
      <th>rating_numerator</th>
      <th>rating_denominator</th>
      <th>name</th>
      <th>dog_stage</th>
      <th>image_url</th>
      <th>...</th>
      <th>first_confidence</th>
      <th>first_dog</th>
      <th>second_prediction</th>
      <th>second_confidence</th>
      <th>second_dog</th>
      <th>third_prediction</th>
      <th>third_confidence</th>
      <th>third_dog</th>
      <th>retweet_count</th>
      <th>favorite_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>756</th>
      <td>778650543019483137</td>
      <td>2016-09-21 17:42:10+00:00</td>
      <td>iphone</td>
      <td>Meet Strider. He thinks he's a sorority girl. ...</td>
      <td>https://twitter.com/dog_rates/status/778650543...</td>
      <td>10</td>
      <td>10</td>
      <td>Strider</td>
      <td>NaN</td>
      <td>https://pbs.twimg.com/media/Cs5ShihWEAAH2ti.jpg</td>
      <td>...</td>
      <td>0.515699</td>
      <td>True</td>
      <td>malinois</td>
      <td>0.300292</td>
      <td>True</td>
      <td>kelpie</td>
      <td>0.087022</td>
      <td>True</td>
      <td>1729.0</td>
      <td>6430.0</td>
    </tr>
    <tr>
      <th>1078</th>
      <td>739485634323156992</td>
      <td>2016-06-05 15:54:48+00:00</td>
      <td>iphone</td>
      <td>This is Kyle. He's a heavy drinker and an avid...</td>
      <td>https://twitter.com/dog_rates/status/739485634...</td>
      <td>6</td>
      <td>10</td>
      <td>Kyle</td>
      <td>NaN</td>
      <td>https://pbs.twimg.com/media/CkMuP7SWkAAD-2R.jpg</td>
      <td>...</td>
      <td>0.640256</td>
      <td>True</td>
      <td>english foxhound</td>
      <td>0.229799</td>
      <td>True</td>
      <td>beagle</td>
      <td>0.037754</td>
      <td>True</td>
      <td>3309.0</td>
      <td>7887.0</td>
    </tr>
  </tbody>
</table>
<p>2 rows × 22 columns</p>
</div>



>#### Issue #4: doggo, pupper, floofer, and puppo columns are no more needed

>#### Define: columns like doggo, pupper, floofer, and puppo will be dropped from twitter_archive_columns because the three columns are now combined in dog_stage column 

#### Code


```python
# to remove doggo, pupper, floofer, and puppo columns
twitter_archive_master.drop(['doggo','pupper','floofer','puppo'], axis =1, inplace=True)
```

#### Test


```python
# list of columns in twitter_archive_master
for i in twitter_archive_master.columns:
    display(i)
```


    'tweet_id'



    'timestamp'



    'source'



    'text'



    'expanded_urls'



    'rating_numerator'



    'rating_denominator'



    'name'



    'dog_stage'



    'image_url'



    'image_number'



    'first_prediction'



    'first_confidence'



    'first_dog'



    'second_prediction'



    'second_confidence'



    'second_dog'



    'third_prediction'



    'third_confidence'



    'third_dog'



    'retweet_count'



    'favorite_count'



```python
# more details of the master dataframe
twitter_archive_master.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 2356 entries, 0 to 2355
    Data columns (total 25 columns):
     #   Column              Non-Null Count  Dtype              
    ---  ------              --------------  -----              
     0   tweet_id            2356 non-null   int64              
     1   timestamp           2356 non-null   datetime64[ns, UTC]
     2   source              2356 non-null   object             
     3   text                2356 non-null   object             
     4   expanded_urls       2297 non-null   object             
     5   rating_numerator    2356 non-null   int64              
     6   rating_denominator  2356 non-null   int64              
     7   name                2356 non-null   object             
     8   dog_stage           380 non-null    object             
     9   image_url           2075 non-null   object             
     10  image_number        2075 non-null   float64            
     11  first_prediction    2075 non-null   object             
     12  first_confidence    2075 non-null   float64            
     13  first_dog           2075 non-null   object             
     14  second_prediction   2075 non-null   object             
     15  second_confidence   2075 non-null   float64            
     16  second_dog          2075 non-null   object             
     17  third_prediction    2075 non-null   object             
     18  third_confidence    2075 non-null   float64            
     19  third_dog           2075 non-null   object             
     20  retweet_count       2354 non-null   float64            
     21  favorite_count      2354 non-null   float64            
     22  day_name            2356 non-null   object             
     23  month               2356 non-null   object             
     24  year_month          2356 non-null   period[M]          
    dtypes: datetime64[ns, UTC](1), float64(6), int64(3), object(14), period[M](1)
    memory usage: 460.3+ KB
    

#### Storing data
<a id = '####Storing-Data'></a>

Since our datasets have been gathered, assessed, and cleaned. Let us now merge the datasets and save them a master dataset to a csv file named "twitter_archive_master.csv".

After storing the datasets successfully, we will look for some insights in order to come up with some visualizations


```python
# storing of master dataframe 
twitter_archive_master = twitter_archive_master.to_csv('twitter_archive_master.csv', index=False)
```

## Analyzing and Visualizing Data
<a id = '## Analyzing-and-Visualizing-Data'><a/>

---
Thank you for following to this extent. Next task is to analyse and visualize the list insights.

>#### Insights:
>1. Is there any relationship between retweet count and          favorite count, if so, what type?   

>2. What is tweet frequency on each day of the week?

>3. How many tweets recorded for each month of all the years?

>4. What is the number of tweets recorded for each dog stage      on week days?

>5. What is the percentage of tweets received by each dog      stage?

>6. What are the tweets platforms used and their tweets percentage?


```python
# loading twitter_archive_ master dataframe
twitter_archive_master = pd.read_csv('twitter_archive_master.csv')
```

### Visualizations
<a id = '### Visualizations'></a>

- #### Is there any relationships between retweet count and favorite count, if so, what type?


```python
# scatter plot for favorite count and retweet count relationship
#sns.set_theme(color_codes = True)
sns.regplot(x="retweet_count", y="favorite_count", fit_reg=False,
            data = twitter_archive_master, color ='black')
plt.xlabel('Retweet Count', size = 13)
plt.ylabel('Favorite Count', size = 13)
plt.title('Relationship between Favorite Count and Retweet Count', size = 13);
```


    
![png](output_147_0.png)
    


**Observations**  
The scatter plot analysis revealed that as favourite tweets increased so also tweets that were retweeted. This shows there is positive relationship between tweets retweeted and tweets that are favourites. This means that tweets that are liked have possibility of been reposted multiple times by many fans.

Let's now examine the number of tweets in each day.

- #### What is twwet frequency on each day of the week?


```python
# to know number of tweets daily
weekdays_tweet= twitter_archive_master.day_name.value_counts()

# converting to dataframe and renaming columns
weekdays_tweet = weekdays_tweet.to_frame().reset_index(
).rename(columns={'index':'Day','day_name':'Count'})

weekdays_tweet
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Day</th>
      <th>Count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Monday</td>
      <td>384</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Tuesday</td>
      <td>356</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Wednesday</td>
      <td>354</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Friday</td>
      <td>333</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Thursday</td>
      <td>326</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Saturday</td>
      <td>309</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Sunday</td>
      <td>294</td>
    </tr>
  </tbody>
</table>
</div>




```python
# chart for daily tweet
weekdays_tweet.plot(kind = 'bar', x = 'Day', 
                     color = 'royalblue',
                   figsize = (6,6), title ='Tweet Count by Weekdays',
                   fontsize = 10);
```


    
![png](output_151_0.png)
    


**Observations**
The tweet frequency was quite steady with slight decline from Monday through Sunday. Highest number of tweets which is 384, was recorded on Monday while, lowest number of tweets 294 was recorded on Sunday. This means that WeRateDogs fans are more active between Monday through the midweek and some of them would be off the page during weekend.

Let's now check frequency of tweets in relation to months.

- #### How many tweets recorded for each month of all the years observed?


```python
# to know number of tweets yearly by month
year_month_tweet = twitter_archive_master.year_month.value_counts()

# converting to dataframe and renaming of columns
year_month_tweet = year_month_tweet.to_frame().reset_index(
).rename(columns={'index':'Year_Month','year_month':'Count'}
        ).sort_values('Year_Month')

year_month_tweet 
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Year_Month</th>
      <th>Count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>2015-11</td>
      <td>302</td>
    </tr>
    <tr>
      <th>0</th>
      <td>2015-12</td>
      <td>388</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2016-01</td>
      <td>194</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2016-02</td>
      <td>125</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2016-03</td>
      <td>137</td>
    </tr>
    <tr>
      <th>16</th>
      <td>2016-04</td>
      <td>60</td>
    </tr>
    <tr>
      <th>15</th>
      <td>2016-05</td>
      <td>60</td>
    </tr>
    <tr>
      <th>6</th>
      <td>2016-06</td>
      <td>97</td>
    </tr>
    <tr>
      <th>5</th>
      <td>2016-07</td>
      <td>105</td>
    </tr>
    <tr>
      <th>12</th>
      <td>2016-08</td>
      <td>75</td>
    </tr>
    <tr>
      <th>11</th>
      <td>2016-09</td>
      <td>84</td>
    </tr>
    <tr>
      <th>10</th>
      <td>2016-10</td>
      <td>88</td>
    </tr>
    <tr>
      <th>9</th>
      <td>2016-11</td>
      <td>88</td>
    </tr>
    <tr>
      <th>13</th>
      <td>2016-12</td>
      <td>70</td>
    </tr>
    <tr>
      <th>7</th>
      <td>2017-01</td>
      <td>94</td>
    </tr>
    <tr>
      <th>8</th>
      <td>2017-02</td>
      <td>88</td>
    </tr>
    <tr>
      <th>14</th>
      <td>2017-03</td>
      <td>68</td>
    </tr>
    <tr>
      <th>17</th>
      <td>2017-04</td>
      <td>60</td>
    </tr>
    <tr>
      <th>20</th>
      <td>2017-05</td>
      <td>56</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2017-06</td>
      <td>59</td>
    </tr>
    <tr>
      <th>19</th>
      <td>2017-07</td>
      <td>56</td>
    </tr>
    <tr>
      <th>21</th>
      <td>2017-08</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>




```python
def bar_chart(data, x, color, title, figsize, fontsize):
    """
    This function with six arguments will plot a simple 
    bar chart.
    """
    data.plot(kind = 'bar', x = x, title = title, color = color, figsize = figsize, fontsize = fontsize)
    
```


```python
# chart for tweets of all the months
bar_chart(year_month_tweet , 'Year_Month', 'royalblue', 'Number of Tweets by Yearly-Month', (8,4), 13)
```


    
![png](output_156_0.png)
    


**Observations**

The data timeline was November 2015 to August 2017, which is 21 months. Within this period, the first five months (November 2015 – March 2016) recorded highest number of tweets with highest been in the month of December 2015. However, number of tweets dropped sharply from April 2016 and maintained the low trend till July 2017 which is 15 months period until the lowest number of tweets were recorded in August 2017. This deep inspection calls for further analysis to confirm the main reasons WeRateDogs popularity dropped sharply after five months.

Next, we will look at number of tweets received by each dog stage on week days.

- #### What is the number of tweets recorded for each dog stage on week days?


```python
# number of daily tweets for each dog 
dog_daily_tweet = twitter_archive_master.groupby('day_name')['dog_stage'].value_counts()

dog_daily_tweet = dog_daily_tweet.to_frame().rename(columns={'dog_stage': 'Count'}).reset_index()

# dog stage chart for tweets of each weekday 
ax = sns.barplot(x = 'day_name', 
            y = 'Count', hue = 'dog_stage', 
            data = dog_daily_tweet, 
            order = ['Monday', 'Tuesday', 'Wednesday', 
                     'Thursday', 'Friday', 'Saturday', 'Sunday'])
ax.set_xlabel('Weekdays', size = 15)
ax.set_ylabel('Number of Tweets', size = 15)
ax.set_title('Dog Stage Tweet by Weekdays', size = 15)
plt.legend(loc = 2, bbox_to_anchor = (1, 1));
```


    
![png](output_159_0.png)
    


**Observations**

Among the four dog stages (pupper, doggo, puppo, and floofer) pupper recorded the highest from Monday through Sunday. Doggo is in distant second position followed by puppo and floofer having just a fraction. Pupper recorded highest number of tweets on Wednesday, doggo best day was Tuesday. Meanwhile, puppo’s lucky day was Friday and floofer’s day was Saturday.

It will be more insightful to look at percentage of tweets received by each dog stage.

- #### What is the percentage of tweets received by each dog stage?


```python
# number of tweet for dog stages
dog_stage = twitter_archive_master.dog_stage.value_counts()


plt.pie(dog_stage, startangle = 30, labeldistance = 1.2, 
        counterclock = True, wedgeprops = {'width':0.4, 'linewidth': 1})
plt.title('Dog Stages', fontweight = 'bold', fontsize = 15)

plt.legend(['pupper  64%', 'doggo  26%', 'puppo  8%', 'floofer  2%'], 
           bbox_to_anchor = (1,0.8), bbox_transform=plt.gcf().transFigure, loc = 'center right')
plt.gca().axis('equal');
```


    
![png](output_162_0.png)
    


**Observations**

Among the four dog stages, the most popular which is also the youngest stage is pupper with 64% tweet followed by doggo which is older, gathering 26% of the tweets. Puppo has 8% while floofer which is the oldest dog stage has 2%. This insight reveals human tendency to show more interest in young dogs because of their cuteness compared to older dogs.

It will be unjust if we fail to look at platforms used by fans for tweeting. This insight will be the last for this project.

- #### What are the tweet platforms used?


```python
# number of tweet sources
tweet_source = twitter_archive_master.source.value_counts()

# chart showing platforms used for tweeting
plt.pie(tweet_source, counterclock = False)
plt.title('Tweet Sources', fontweight = 'bold', fontsize = 15)
plt.legend(['iphone  94%', 'vine  4%', 'twitter  1.8%', 'tweetdeck  0.2%'], 
           bbox_to_anchor = (1.1,0.5), bbox_transform=plt.gcf().transFigure, loc = 'center right')
plt.gca().axis('equal');
```


    
![png](output_165_0.png)
    


**Observations**

The tweet platforms used were iphone, vine, twitter, and tweetdeck. Iphone recorded 94%, while vine recorded 4%. Twitter platform recorded 1.8% while tweetdeck settled for 0.2%. This analysis has shown that core fans of WeRateDogs are iphone users.

## Resources:
<a id = '##Resources:'></a>

---

https://pythonguides.com/matplotlib-pie-chart/

https://stackoverflow.com/questions/72426371/extract-month-name-from-date-column-pandas

https://datascientyst.com/extract-month-and-year-datetime-column-in-pandas/

https://www.geeksforgeeks.org/change-the-legend-position-in-matplotlib/

https://stackoverflow.com/questions/43272206/python-legend-overlaps-with-the-pie-chart


```python

```
